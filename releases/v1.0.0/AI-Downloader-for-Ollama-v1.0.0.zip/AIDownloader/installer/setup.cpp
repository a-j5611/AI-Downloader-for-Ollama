// setup.cpp —— AI Downloader 安装程序（Win32 GUI，单文件，自带卸载器）
//
// 特点：
//   * 整个程序以 ZIP（STORE）形式内嵌在 exe 资源里，安装即解包，**单文件分发**；
//   * 装到 %LOCALAPPDATA%\Programs\AI Downloader，**不需要管理员权限**；
//   * 自动检测 Python（pythonw + tkinter + Pillow）与 Ollama，并给出明确提示；
//   * 创建桌面/开始菜单快捷方式（COM IShellLink），写入“应用和功能”卸载项；
//   * 复制自身为 Uninstall.exe，卸载时删除文件/快捷方式/注册表，可选清理配置；
//   * 支持静默与自定义目录：/S  /D=路径  /uninstall  /purge  /nolaunch  /noicons
//
// 编译：见 build.bat（g++ + windres，仅链接系统库）
#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlobj.h>

#include <cstdio>
#include <cstdint>
#include <cwchar>
#include <string>
#include <vector>

#include "zip.hpp"

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "uuid.lib")

// ============================================================ 常量
#define APP_NAME     L"AI Downloader"
#define APP_VERSION  L"1.0.0"
#define APP_PUBLISHER L"a-j5611"
#define APP_URL      L"https://github.com/a-j5611/AI-Downloader-for-Ollama"
#define APP_EXE      L"AIDownloader.pyw"
#define LAUNCHER     L"run.bat"
#define UNINST_EXE   L"Uninstall.exe"
#define REG_KEY      L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\AIDownloader"
#define PAYLOAD_ID   101

enum { ID_DIR = 1001, ID_BROWSE, ID_DESKTOP, ID_STARTMENU, ID_LAUNCH, ID_INSTALL, ID_QUIT,
       ID_PROGRESS, ID_STATUS, ID_ENVINFO };

struct EnvInfo {
    std::wstring pythonw;
    bool tkinter = false;
    bool pillow = false;
    bool ollama = false;
    std::wstring ollamaPath;
};

static EnvInfo g_env_cache;      // 环境检测结果（窗口创建时显示）

static HINSTANCE g_inst;
static HWND g_main, g_dir, g_status, g_progress, g_env;
static HWND g_cbDesktop, g_cbStartMenu, g_cbLaunch;
static std::vector<uint8_t> g_payload;
static std::vector<zip::Entry> g_entries;
static std::wstring g_installDir;
static bool g_silent = false, g_noIcons = false, g_noLaunch = false, g_uninstall = false,
            g_purge = false;
static volatile LONG g_progressValue = 0;
static volatile LONG g_progressMax = 1;

// ============================================================ 小工具
static std::wstring utf8ToWide(const std::string &s) {
    if (s.empty()) return L"";
    int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
    std::wstring out(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n);
    return out;
}

static std::string wideToUtf8(const std::wstring &s) {
    if (s.empty()) return "";
    int n = WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0, nullptr,
                                nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.c_str(), (int)s.size(), &out[0], n, nullptr, nullptr);
    return out;
}

static std::wstring joinPath(const std::wstring &a, const std::wstring &b) {
    if (a.empty()) return b;
    std::wstring out = a;
    if (out.back() != L'\\' && out.back() != L'/') out += L'\\';
    return out + b;
}

static bool fileExists(const std::wstring &path) {
    DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
}

static bool dirExists(const std::wstring &path) {
    DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY);
}

static bool makeDirs(const std::wstring &path) {
    if (path.empty()) return false;
    if (dirExists(path)) return true;
    std::wstring parent = path;
    size_t pos = parent.find_last_of(L"\\/");
    if (pos != std::wstring::npos && pos > 2) {
        if (!makeDirs(parent.substr(0, pos))) return false;
    }
    return CreateDirectoryW(path.c_str(), nullptr) || GetLastError() == ERROR_ALREADY_EXISTS;
}

static bool writeFile(const std::wstring &path, const std::vector<uint8_t> &data) {
    makeDirs(path.substr(0, path.find_last_of(L"\\/")));
    HANDLE h = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return false;
    DWORD written = 0;
    bool ok = true;
    if (!data.empty())
        ok = WriteFile(h, data.data(), (DWORD)data.size(), &written, nullptr) &&
             written == data.size();
    CloseHandle(h);
    return ok;
}

static std::wstring quote(const std::wstring &s) { return L"\"" + s + L"\""; }

static void logLine(const std::string &text) {
    wchar_t temp[MAX_PATH] = {0};
    GetTempPathW(MAX_PATH, temp);
    std::wstring path = joinPath(temp, L"aidl_setup.log");
    HANDLE h = CreateFileW(path.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ, nullptr,
                           OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return;
    SYSTEMTIME st;
    GetLocalTime(&st);
    char line[1024];
    int n = _snprintf(line, sizeof(line), "[%02d:%02d:%02d] %s\r\n", st.wHour, st.wMinute,
                      st.wSecond, text.c_str());
    DWORD written = 0;
    if (n > 0) WriteFile(h, line, (DWORD)n, &written, nullptr);
    CloseHandle(h);
}

static void status(const std::wstring &text) {
    if (g_status) SetWindowTextW(g_status, text.c_str());
    if (!g_silent) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

static void setProgress(int value) {
    InterlockedExchange(&g_progressValue, value);
    if (g_progress && !g_silent) {
        SendMessageW(g_progress, PBM_SETPOS, (WPARAM)value, 0);
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

// 运行命令并收集输出（用于 Python 环境检测）
static bool runCapture(const std::wstring &cmdline, std::string &output, DWORD timeoutMs = 15000) {
    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 0)) return false;
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = wr;
    si.hStdError = wr;
    si.hStdInput = nullptr;
    PROCESS_INFORMATION pi{};

    std::wstring cmd = cmdline;
    BOOL started = CreateProcessW(nullptr, &cmd[0], nullptr, nullptr, TRUE,
                                  CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(wr);
    if (!started) {
        CloseHandle(rd);
        return false;
    }
    output.clear();
    char buf[4096];
    DWORD read = 0, waited = 0;
    while (waited < timeoutMs) {
        DWORD avail = 0;
        BOOL peeked = PeekNamedPipe(rd, nullptr, 0, nullptr, &avail, nullptr);
        if (peeked && avail > 0) {
            if (ReadFile(rd, buf, sizeof(buf) - 1, &read, nullptr) && read > 0) {
                buf[read] = 0;
                output += buf;
            }
        }
        // 进程结束后把剩余数据排空（避免卡在 ReadFile 上）
        if (WaitForSingleObject(pi.hProcess, peeked ? 20 : 60) == WAIT_OBJECT_0) {
            for (int guard = 0; guard < 64; ++guard) {
                DWORD left = 0;
                if (!PeekNamedPipe(rd, nullptr, 0, nullptr, &left, nullptr) || left == 0) break;
                if (!ReadFile(rd, buf, sizeof(buf) - 1, &read, nullptr) || read == 0) break;
                buf[read] = 0;
                output += buf;
            }
            break;
        }
        waited += 60;
    }
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(rd);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    return code == 0;
}

// ============================================================ 资源
static bool loadPayload() {
    HRSRC res = FindResourceW(nullptr, MAKEINTRESOURCEW(PAYLOAD_ID), RT_RCDATA);
    if (!res) return false;
    DWORD size = SizeofResource(nullptr, res);
    HGLOBAL mem = LoadResource(nullptr, res);
    if (!mem || !size) return false;
    const void *ptr = LockResource(mem);
    if (!ptr) return false;
    g_payload.assign((const uint8_t *)ptr, (const uint8_t *)ptr + size);
    zip::Reader reader(g_payload.data(), g_payload.size());
    if (!reader.parse()) return false;
    g_entries = reader.entries();
    return true;
}

// ============================================================ 环境检测
static bool checkPythonAt(const std::wstring &pythonw, bool &tk, bool &pil) {
    std::wstring python = pythonw;
    size_t pos = python.find_last_of(L"\\/");
    std::wstring dir = (pos == std::wstring::npos) ? L"" : python.substr(0, pos);
    std::wstring exe = joinPath(dir, L"python.exe");
    if (!fileExists(exe)) exe = pythonw;
    std::string out;
    std::wstring cmd = quote(exe) + L" -c \"import tkinter;print('TK');import PIL;print('PIL')\"";
    bool ok = runCapture(cmd, out, 20000);
    tk = out.find("TK") != std::string::npos;
    pil = out.find("PIL") != std::string::npos;
    return ok || tk || pil;
}

static void findPython(EnvInfo &env) {
    std::vector<std::wstring> candidates;

    // 1) 安装目录旁边的 python-path.txt（便携覆盖）
    if (!g_installDir.empty()) {
        std::wstring cfg = joinPath(g_installDir, L"python-path.txt");
        if (fileExists(cfg)) {
            HANDLE h = CreateFileW(cfg.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                                   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
            if (h != INVALID_HANDLE_VALUE) {
                char buf[1024] = {0};
                DWORD read = 0;
                ReadFile(h, buf, sizeof(buf) - 1, &read, nullptr);
                CloseHandle(h);
                std::string text(buf);
                while (!text.empty() && (text.back() == '\n' || text.back() == '\r' ||
                                         text.back() == ' '))
                    text.pop_back();
                if (!text.empty()) candidates.push_back(utf8ToWide(text));
            }
        }
    }

    // 2) py 启动器（从注册表/环境拿真实路径）
    {
        wchar_t buf[MAX_PATH * 2] = {0};
        if (SearchPathW(nullptr, L"py.exe", nullptr, MAX_PATH * 2, buf, nullptr)) {
            std::string out;
            if (runCapture(quote(buf) + L" -3 -c \"import sys;print(sys.executable)\"", out,
                           20000)) {
                while (!out.empty() && (out.back() == '\n' || out.back() == '\r' ||
                                        out.back() == ' '))
                    out.pop_back();
                size_t nl = out.find('\n');
                if (nl != std::string::npos) out = out.substr(0, nl);
                if (!out.empty()) {
                    std::wstring exe = utf8ToWide(out);
                    std::wstring w = exe;
                    size_t slash = w.find_last_of(L"\\/");
                    if (slash != std::wstring::npos)
                        w = joinPath(w.substr(0, slash), L"pythonw.exe");
                    candidates.push_back(fileExists(w) ? w : exe);
                }
            }
        }
    }

    // 3) 常见安装位置
    wchar_t local[MAX_PATH] = {0}, pf[MAX_PATH] = {0};
    SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, 0, local);
    SHGetFolderPathW(nullptr, CSIDL_PROGRAM_FILES, nullptr, 0, pf);
    const wchar_t *roots[] = {local, pf, L"C:\\"};
    const wchar_t *subs[] = {L"Programs\\Python\\Python313\\pythonw.exe",
                             L"Programs\\Python\\Python312\\pythonw.exe",
                             L"Programs\\Python\\Python311\\pythonw.exe",
                             L"Programs\\Python\\Python310\\pythonw.exe",
                             L"Python313\\pythonw.exe", L"Python312\\pythonw.exe",
                             L"Python311\\pythonw.exe", L"Python310\\pythonw.exe",
                             L"Python39\\pythonw.exe"};
    for (const wchar_t *root : roots)
        for (const wchar_t *sub : subs) {
            std::wstring p = joinPath(root, sub);
            if (fileExists(p)) candidates.push_back(p);
        }

    // 4) PATH 里的 pythonw / python
    {
        wchar_t buf[MAX_PATH * 2] = {0};
        if (SearchPathW(nullptr, L"pythonw.exe", nullptr, MAX_PATH * 2, buf, nullptr))
            candidates.push_back(buf);
        if (SearchPathW(nullptr, L"python.exe", nullptr, MAX_PATH * 2, buf, nullptr))
            candidates.push_back(buf);
    }

    // 5) 本机开发用的运行时（有就顺手用上）
    {
        wchar_t home[MAX_PATH] = {0};
        SHGetFolderPathW(nullptr, CSIDL_PROFILE, nullptr, 0, home);
        std::wstring p = joinPath(home,
            L".dsh\\dsh-runtimes\\dsh-primary-runtime\\dependencies\\python\\pythonw.exe");
        if (fileExists(p)) candidates.push_back(p);
    }

    for (const std::wstring &cand : candidates) {
        if (!fileExists(cand)) continue;
        bool tk = false, pil = false;
        if (checkPythonAt(cand, tk, pil)) {
            env.pythonw = cand;
            env.tkinter = tk;
            env.pillow = pil;
            return;
        }
    }
    if (!candidates.empty()) env.pythonw = candidates.front();
}

static void findOllama(EnvInfo &env) {
    const wchar_t *names[] = {L"ollama.exe"};
    wchar_t buf[MAX_PATH * 2] = {0};
    for (const wchar_t *n : names) {
        if (SearchPathW(nullptr, n, nullptr, MAX_PATH * 2, buf, nullptr)) {
            env.ollama = true;
            env.ollamaPath = buf;
        }
    }
    wchar_t local[MAX_PATH] = {0};
    SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, 0, local);
    std::vector<std::wstring> extra = {
        joinPath(local, L"Programs\\Ollama\\ollama.exe"),
        L"D:\\Ollama\\ollama.exe", L"C:\\Ollama\\ollama.exe",
        L"E:\\Ollama\\ollama.exe"};
    for (const std::wstring &p : extra) {
        if (fileExists(p)) {
            env.ollama = true;
            if (env.ollamaPath.empty()) env.ollamaPath = p;
        }
    }
}

static std::wstring envSummary(const EnvInfo &env, bool multiline) {
    std::wstring out;
    auto line = [&](const std::wstring &s) {
        if (!out.empty()) out += multiline ? L"\r\n" : L"    ";
        out += s;
    };
    if (env.pythonw.empty())
        line(L"✗ 未找到 Python：安装后无法运行，请先安装 Python 3.10+（勾选 tcl/tk）");
    else {
        line(L"✓ Python：" + env.pythonw);
        if (!env.tkinter)
            line(L"✗ 该 Python 缺少 tkinter（安装时请勾选 tcl/tk and IDLE）");
        if (!env.pillow)
            line(L"! 缺少 Pillow（背景图与图片处理需要）：pip install pillow");
    }
    line(env.ollama ? (L"✓ Ollama：" + env.ollamaPath)
                    : L"! 未检测到 Ollama：程序可运行，但需要 Ollama 才能下载模型");
    return out;
}

// ============================================================ 快捷方式 / 注册表
static bool createShortcut(const std::wstring &lnkPath, const std::wstring &target,
                           const std::wstring &args, const std::wstring &workDir,
                           const std::wstring &icon) {
    IShellLinkW *link = nullptr;
    if (FAILED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IShellLinkW, (void **)&link)))
        return false;
    link->SetPath(target.c_str());
    if (!args.empty()) link->SetArguments(args.c_str());
    if (!workDir.empty()) link->SetWorkingDirectory(workDir.c_str());
    if (!icon.empty()) link->SetIconLocation(icon.c_str(), 0);
    link->SetDescription(L"AI Downloader —— Ollama 模型下载器");

    IPersistFile *file = nullptr;
    bool ok = false;
    if (SUCCEEDED(link->QueryInterface(IID_IPersistFile, (void **)&file))) {
        ok = SUCCEEDED(file->Save(lnkPath.c_str(), TRUE));
        file->Release();
    }
    link->Release();
    return ok;
}

static void writeRegistry(const std::wstring &dir, uint64_t sizeBytes) {
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, REG_KEY, 0, nullptr, 0, KEY_WRITE, nullptr, &key,
                        nullptr) != ERROR_SUCCESS)
        return;
    auto setStr = [&](const wchar_t *name, const std::wstring &value) {
        RegSetValueExW(key, name, 0, REG_SZ, (const BYTE *)value.c_str(),
                       (DWORD)((value.size() + 1) * sizeof(wchar_t)));
    };
    setStr(L"DisplayName", L"AI Downloader（Ollama 模型下载器）");
    setStr(L"DisplayVersion", APP_VERSION);
    setStr(L"Publisher", APP_PUBLISHER);
    setStr(L"InstallLocation", dir);
    setStr(L"DisplayIcon", joinPath(dir, APP_EXE));
    setStr(L"URLInfoAbout", APP_URL);
    setStr(L"UninstallString", quote(joinPath(dir, UNINST_EXE)) + L" /uninstall");
    setStr(L"QuietUninstallString", quote(joinPath(dir, UNINST_EXE)) + L" /uninstall /S");
    DWORD sizeKb = (DWORD)(sizeBytes / 1024);
    RegSetValueExW(key, L"EstimatedSize", 0, REG_DWORD, (const BYTE *)&sizeKb, sizeof(sizeKb));
    DWORD one = 1;
    RegSetValueExW(key, L"NoModify", 0, REG_DWORD, (const BYTE *)&one, sizeof(one));
    RegCloseKey(key);
}

static void removeRegistry() {
    RegDeleteKeyW(HKEY_CURRENT_USER, REG_KEY);
}

static bool wantShortcut(int id) {
    if (g_noIcons) return false;
    if (g_silent) return true;
    HWND cb = (id == ID_DESKTOP) ? g_cbDesktop : g_cbStartMenu;
    return cb && SendMessageW(cb, BM_GETCHECK, 0, 0) == BST_CHECKED;
}

// ============================================================ 安装
static const wchar_t *LAUNCHER_BAT =
    L"@echo off\r\n"
    L"rem Launcher for AI Downloader (generated by the installer).\r\n"
    L"setlocal\r\n"
    L"set \"HERE=%~dp0\"\r\n"
    L"set \"PYW={PYTHONW}\"\r\n"
    L"if not exist \"%PYW%\" (\r\n"
    L"  echo pythonw.exe not found: %PYW%\r\n"
    L"  echo Please reinstall AI Downloader or install Python 3.10+.\r\n"
    L"  pause\r\n"
    L"  exit /b 1\r\n"
    L")\r\n"
    L"start \"\" \"%PYW%\" \"%HERE%{APPEXE}\"\r\n"
    L"exit /b 0\r\n";

static bool installFiles(const EnvInfo &env, std::wstring &error) {
    InterlockedExchange(&g_progressMax, (LONG)g_entries.size() + 2);
    int step = 0;
    uint64_t totalBytes = 0;

    if (!makeDirs(g_installDir)) {
        error = L"无法创建安装目录：" + g_installDir;
        return false;
    }

    for (const zip::Entry &e : g_entries) {
        if (e.name.empty() || e.name.back() == '/') continue;
        std::wstring relative = utf8ToWide(e.name);
        for (wchar_t &c : relative)
            if (c == L'/') c = L'\\';
        std::wstring target = joinPath(g_installDir, relative);
        std::vector<uint8_t> data;
        if (e.size > 0 && e.offset + e.size <= g_payload.size()) {
            const uint8_t *src = g_payload.data() + e.offset;
            data.assign(src, src + e.size);
        }
        totalBytes += data.size();
        if (!writeFile(target, data)) {
            error = L"写入失败：" + target;
            return false;
        }
        status(L"正在安装：" + relative);
        setProgress(++step);
    }

    // 启动器（写成检测到的 pythonw）
    std::wstring bat = LAUNCHER_BAT;
    size_t pos = bat.find(L"{PYTHONW}");
    if (pos != std::wstring::npos)
        bat.replace(pos, 9, env.pythonw.empty() ? std::wstring(L"pythonw.exe") : env.pythonw);
    pos = bat.find(L"{APPEXE}");
    if (pos != std::wstring::npos) bat.replace(pos, 8, APP_EXE);
    std::vector<uint8_t> batData(bat.begin(), bat.end());
    if (!writeFile(joinPath(g_installDir, LAUNCHER), batData)) {
        error = L"无法创建启动脚本";
        return false;
    }
    setProgress(++step);

    // 记录 python 路径，方便以后诊断
    if (!env.pythonw.empty())
        writeFile(joinPath(g_installDir, L"python-path.txt"),
                  std::vector<uint8_t>(wideToUtf8(env.pythonw).begin(),
                                       wideToUtf8(env.pythonw).end()));

    // 卸载器 = 自身副本
    wchar_t self[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, self, MAX_PATH * 2);
    if (_wcsicmp(self, joinPath(g_installDir, UNINST_EXE).c_str()) != 0)
        CopyFileW(self, joinPath(g_installDir, UNINST_EXE).c_str(), FALSE);
    setProgress(++step);

    // 快捷方式
    if (!g_noIcons) {
        std::wstring target = joinPath(g_installDir, LAUNCHER);
        std::wstring work = g_installDir;
        std::wstring icon = joinPath(g_installDir, LAUNCHER);
        wchar_t desktop[MAX_PATH] = {0}, programs[MAX_PATH] = {0};
        SHGetFolderPathW(nullptr, CSIDL_DESKTOPDIRECTORY, nullptr, 0, desktop);
        SHGetFolderPathW(nullptr, CSIDL_PROGRAMS, nullptr, 0, programs);
        if (wantShortcut(ID_DESKTOP) && *desktop)
            createShortcut(joinPath(desktop, L"AI Downloader.lnk"), target, L"", work, icon);
        if (wantShortcut(ID_STARTMENU) && *programs) {
            std::wstring folder = joinPath(programs, L"AI Downloader");
            makeDirs(folder);
            createShortcut(joinPath(folder, L"AI Downloader.lnk"), target, L"", work, icon);
            createShortcut(joinPath(folder, L"卸载 AI Downloader.lnk"),
                           joinPath(g_installDir, UNINST_EXE), L"/uninstall", work, icon);
        }
    }

    writeRegistry(g_installDir, totalBytes);
    return true;
}

static void deleteShortcuts() {
    wchar_t desktop[MAX_PATH] = {0}, programs[MAX_PATH] = {0};
    SHGetFolderPathW(nullptr, CSIDL_DESKTOPDIRECTORY, nullptr, 0, desktop);
    SHGetFolderPathW(nullptr, CSIDL_PROGRAMS, nullptr, 0, programs);
    if (*desktop) DeleteFileW(joinPath(desktop, L"AI Downloader.lnk").c_str());
    if (*programs) {
        std::wstring folder = joinPath(programs, L"AI Downloader");
        DeleteFileW(joinPath(folder, L"AI Downloader.lnk").c_str());
        DeleteFileW(joinPath(folder, L"卸载 AI Downloader.lnk").c_str());
        RemoveDirectoryW(folder.c_str());
    }
}

static bool removeTree(const std::wstring &dir) {
    std::wstring pattern = joinPath(dir, L"*");
    WIN32_FIND_DATAW fd{};
    HANDLE h = FindFirstFileW(pattern.c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do {
            if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0) continue;
            std::wstring path = joinPath(dir, fd.cFileName);
            if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                removeTree(path);
            else {
                SetFileAttributesW(path.c_str(), FILE_ATTRIBUTE_NORMAL);
                DeleteFileW(path.c_str());
            }
        } while (FindNextFileW(h, &fd));
        FindClose(h);
    }
    return RemoveDirectoryW(dir.c_str()) != 0;
}

static bool doUninstall(std::wstring &error) {
    std::wstring dir = g_installDir;
    if (dir.empty()) {
        HKEY key = nullptr;
        if (RegOpenKeyExW(HKEY_CURRENT_USER, REG_KEY, 0, KEY_READ, &key) == ERROR_SUCCESS) {
            wchar_t buf[MAX_PATH * 2] = {0};
            DWORD size = sizeof(buf), type = 0;
            if (RegQueryValueExW(key, L"InstallLocation", nullptr, &type, (BYTE *)buf,
                                 &size) == ERROR_SUCCESS)
                dir = buf;
            RegCloseKey(key);
        }
    }
    if (dir.empty()) {
        error = L"找不到安装位置";
        return false;
    }
    if (!g_silent && !g_purge) {
        std::wstring msg = L"确定要卸载 AI Downloader 吗？\r\n\r\n安装位置：" + dir +
                           L"\r\n\r\n（聊天/设置等配置在 %APPDATA%\\AIDownloader，默认保留）";
        if (MessageBoxW(nullptr, msg.c_str(), L"卸载 AI Downloader",
                        MB_OKCANCEL | MB_ICONQUESTION) != IDOK)
            return false;
    }
    deleteShortcuts();
    removeRegistry();

    // 删除自带的文件（按 payload 清单 + 生成的文件）
    std::vector<std::wstring> files;
    for (const zip::Entry &e : g_entries) {
        std::wstring rel = utf8ToWide(e.name);
        for (wchar_t &c : rel)
            if (c == L'/') c = L'\\';
        files.push_back(rel);
    }
    files.push_back(LAUNCHER);
    files.push_back(L"python-path.txt");
    wchar_t self[MAX_PATH * 2] = {0};
    GetModuleFileNameW(nullptr, self, MAX_PATH * 2);
    for (const std::wstring &rel : files) {
        std::wstring p = joinPath(dir, rel);
        if (_wcsicmp(p.c_str(), self) == 0) continue;
        DeleteFileW(p.c_str());
    }
    // 逐层删空目录
    for (int pass = 0; pass < 6; ++pass) {
        std::wstring pattern = joinPath(dir, L"*");
        WIN32_FIND_DATAW fd{};
        HANDLE h = FindFirstFileW(pattern.c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) break;
        bool removedAny = false;
        do {
            if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
            if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0) continue;
            std::wstring sub = joinPath(dir, fd.cFileName);
            if (removeTree(sub)) removedAny = true;
        } while (FindNextFileW(h, &fd));
        FindClose(h);
        if (!removedAny) break;
    }
    if (g_purge) {
        wchar_t appdata[MAX_PATH] = {0};
        SHGetFolderPathW(nullptr, CSIDL_APPDATA, nullptr, 0, appdata);
        if (*appdata) removeTree(joinPath(appdata, L"AIDownloader"));
    }
    // 自己：延迟自删除（批处理在进程退出后动手）
    wchar_t temp[MAX_PATH] = {0};
    GetTempPathW(MAX_PATH, temp);
    std::wstring selfDel = joinPath(temp, L"aidl_uninstall.bat");
    std::wstring content = L"@echo off\r\ntimeout /t 1 /nobreak >nul\r\n"
                           L"del /f /q \"" + std::wstring(self) + L"\"\r\n"
                           L"rd /q /s \"" + dir + L"\" 2>nul\r\n"
                           L"del /f /q \"%~f0\"\r\n";
    std::vector<uint8_t> bytes(content.begin(), content.end());
    writeFile(selfDel, bytes);
    ShellExecuteW(nullptr, L"open", selfDel.c_str(), nullptr, nullptr, SW_HIDE);
    return true;
}

// ============================================================ 界面
static void layout(HWND hwnd) {
    RECT rc;
    GetClientRect(hwnd, &rc);
    int w = rc.right;
    MoveWindow(g_env, 16, 12, w - 32, 78, TRUE);
    MoveWindow(g_dir, 16, 108, w - 130, 26, TRUE);
    MoveWindow(GetDlgItem(hwnd, ID_BROWSE), w - 106, 107, 90, 28, TRUE);
    MoveWindow(g_cbDesktop, 16, 146, 240, 22, TRUE);
    MoveWindow(g_cbStartMenu, 266, 146, 250, 22, TRUE);
    MoveWindow(g_cbLaunch, 16, 172, 320, 22, TRUE);
    MoveWindow(g_progress, 16, 206, w - 32, 18, TRUE);
    MoveWindow(g_status, 16, 230, w - 32, 40, TRUE);
    MoveWindow(GetDlgItem(hwnd, ID_INSTALL), w - 220, 282, 100, 32, TRUE);
    MoveWindow(GetDlgItem(hwnd, ID_QUIT), w - 112, 282, 96, 32, TRUE);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE: {
            g_main = hwnd;
            std::wstring title = std::wstring(L"AI Downloader ") + APP_VERSION + L" 安装程序";
            SetWindowTextW(hwnd, title.c_str());
            g_env = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER |
                                  ES_MULTILINE | ES_READONLY | WS_VSCROLL,
                                  0, 0, 0, 0, hwnd, (HMENU)ID_ENVINFO, g_inst, nullptr);
            CreateWindowW(L"STATIC", L"安装位置：", WS_CHILD | WS_VISIBLE, 16, 90, 200, 18,
                          hwnd, nullptr, g_inst, nullptr);
            g_dir = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER |
                                  ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)ID_DIR, g_inst,
                                  nullptr);
            CreateWindowW(L"BUTTON", L"浏览…", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0,
                          0, 0, hwnd, (HMENU)ID_BROWSE, g_inst, nullptr);
            g_cbDesktop = CreateWindowW(L"BUTTON", L"创建桌面快捷方式",
                                        WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 0, 0, 0, 0,
                                        hwnd, (HMENU)ID_DESKTOP, g_inst, nullptr);
            g_cbStartMenu = CreateWindowW(L"BUTTON", L"创建开始菜单快捷方式",
                                          WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 0, 0, 0, 0,
                                          hwnd, (HMENU)ID_STARTMENU, g_inst, nullptr);
            g_cbLaunch = CreateWindowW(L"BUTTON", L"安装完成后启动 AI Downloader",
                                       WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX, 0, 0, 0, 0,
                                       hwnd, (HMENU)ID_LAUNCH, g_inst, nullptr);
            g_progress = CreateWindowW(PROGRESS_CLASSW, L"", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0,
                                       hwnd, (HMENU)ID_PROGRESS, g_inst, nullptr);
            g_status = CreateWindowW(L"STATIC", L"准备就绪", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0,
                                     hwnd, (HMENU)ID_STATUS, g_inst, nullptr);
            CreateWindowW(L"BUTTON", L"开始安装", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
                          0, 0, 0, 0, hwnd, (HMENU)ID_INSTALL, g_inst, nullptr);
            CreateWindowW(L"BUTTON", L"退出", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd,
                          (HMENU)ID_QUIT, g_inst, nullptr);

            SendMessageW(g_cbDesktop, BM_SETCHECK, BST_CHECKED, 0);
            SendMessageW(g_cbStartMenu, BM_SETCHECK, BST_CHECKED, 0);
            SendMessageW(g_cbLaunch, BM_SETCHECK, BST_CHECKED, 0);
            SetWindowTextW(g_dir, g_installDir.c_str());
            SetWindowTextW(g_env,
                           (L"环境检查：\r\n" + envSummary(g_env_cache, true)).c_str());
            layout(hwnd);
            return 0;
        }
        case WM_SIZE:
            layout(hwnd);
            return 0;
        case WM_COMMAND: {
            switch (LOWORD(wp)) {
                case ID_BROWSE: {
                    BROWSEINFOW bi{};
                    bi.hwndOwner = hwnd;
                    bi.lpszTitle = L"选择安装位置";
                    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
                    LPITEMIDLIST idl = SHBrowseForFolderW(&bi);
                    if (idl) {
                        wchar_t path[MAX_PATH] = {0};
                        SHGetPathFromIDListW(idl, path);
                        CoTaskMemFree(idl);
                        if (*path) SetWindowTextW(g_dir, path);
                    }
                    return 0;
                }
                case ID_INSTALL: {
                    wchar_t buf[MAX_PATH * 2] = {0};
                    GetWindowTextW(g_dir, buf, MAX_PATH * 2);
                    g_installDir = buf;
                    EnableWindow(GetDlgItem(hwnd, ID_INSTALL), FALSE);
                    EnvInfo env = g_env_cache;
                    std::wstring error;
                    bool ok = installFiles(env, error);
                    if (ok) {
                        status(L"安装完成：" + g_installDir);
                        std::wstring msg = L"安装完成！\r\n\r\n" + g_installDir +
                                           L"\r\n\r\n" + envSummary(env, true);
                        MessageBoxW(hwnd, msg.c_str(), L"AI Downloader 安装程序",
                                    MB_OK | MB_ICONINFORMATION);
                        if (SendMessageW(g_cbLaunch, BM_GETCHECK, 0, 0) == BST_CHECKED &&
                            !g_noLaunch)
                            ShellExecuteW(nullptr, L"open",
                                          joinPath(g_installDir, LAUNCHER).c_str(), nullptr,
                                          g_installDir.c_str(), SW_SHOWNORMAL);
                        PostMessageW(hwnd, WM_CLOSE, 0, 0);
                    } else {
                        status(L"安装失败：" + error);
                        MessageBoxW(hwnd, error.c_str(), L"安装失败", MB_OK | MB_ICONERROR);
                        EnableWindow(GetDlgItem(hwnd, ID_INSTALL), TRUE);
                    }
                    return 0;
                }
                case ID_QUIT:
                    PostMessageW(hwnd, WM_CLOSE, 0, 0);
                    return 0;
            }
            return 0;
        }
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

// ============================================================ 入口
static std::wstring defaultInstallDir() {
    wchar_t local[MAX_PATH] = {0};
    SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, 0, local);
    std::wstring dir = joinPath(local, L"Programs");
    makeDirs(dir);
    return joinPath(dir, L"AI Downloader");
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int) {
    g_inst = inst;

    // 命令行
    int argc = 0;
    LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    for (int i = 1; i < argc; ++i) {
        std::wstring a = argv[i];
        if (a == L"/S" || a == L"/s" || a == L"/silent") g_silent = true;
        else if (a == L"/uninstall" || a == L"/u") g_uninstall = true;
        else if (a == L"/purge") g_purge = true;
        else if (a == L"/nolaunch") g_noLaunch = true;
        else if (a == L"/noicons") g_noIcons = true;
        else if (a.rfind(L"/D=", 0) == 0) g_installDir = a.substr(3);
        else if (a.rfind(L"/dir=", 0) == 0) g_installDir = a.substr(5);
    }
    if (argv) LocalFree(argv);

    logLine("---- setup start ----");
    if (!loadPayload()) {
        logLine("ERROR: payload load failed");
        if (!g_silent)
            MessageBoxW(nullptr, L"安装包数据损坏（缺少内嵌文件）", L"AI Downloader 安装程序",
                        MB_OK | MB_ICONERROR);
        return 2;
    }
    logLine("payload entries = " + std::to_string(g_entries.size()));

    if (g_installDir.empty()) g_installDir = defaultInstallDir();

    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    INITCOMMONCONTROLSEX icc{sizeof(icc), ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&icc);

    // 先做环境检测（窗口里要显示）
    logLine("detecting python…");
    findPython(g_env_cache);
    logLine("python = " + wideToUtf8(g_env_cache.pythonw) +
            " tk=" + (g_env_cache.tkinter ? "1" : "0") +
            " pil=" + (g_env_cache.pillow ? "1" : "0"));
    findOllama(g_env_cache);
    logLine("ollama = " + (g_env_cache.ollama ? "1" : "0"));

    if (g_uninstall) {
        std::wstring error;
        bool ok = doUninstall(error);
        CoUninitialize();
        if (g_silent) return ok ? 0 : 1;
        if (!ok && !error.empty())
            MessageBoxW(nullptr, error.c_str(), L"卸载", MB_OK | MB_ICONERROR);
        else if (ok)
            MessageBoxW(nullptr, L"AI Downloader 已卸载。", L"卸载", MB_OK | MB_ICONINFORMATION);
        return 0;
    }

    if (g_silent) {
        std::wstring error;
        logLine("silent install -> " + wideToUtf8(g_installDir));
        bool ok = installFiles(g_env_cache, error);
        logLine(ok ? "silent install OK" : ("silent install FAILED: " + wideToUtf8(error)));
        CoUninitialize();
        return ok ? 0 : 1;
    }

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"AIDownloaderSetup";
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    RegisterClassExW(&wc);

    int w = 640, h = 372;
    int x = (GetSystemMetrics(SM_CXSCREEN) - w) / 2;
    int y = (GetSystemMetrics(SM_CYSCREEN) - h) / 2;
    HWND hwnd = CreateWindowExW(0, L"AIDownloaderSetup",
                                L"AI Downloader 安装程序",
                                WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                                x, y, w, h, nullptr, nullptr, inst, nullptr);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (!IsDialogMessageW(hwnd, &msg)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    CoUninitialize();
    return 0;
}

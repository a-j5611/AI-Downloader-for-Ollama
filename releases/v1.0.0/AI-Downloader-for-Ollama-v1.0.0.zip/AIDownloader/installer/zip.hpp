// zip.hpp —— 极简 ZIP 读取器（只处理 STORE 存储方式）
//
// 安装包把整个程序以“不压缩”方式打进 exe 的资源里：
//   * 不压缩 -> 不需要实现 inflate，代码极小、没有第三方依赖；
//   * payload 只有几百 KB，压不压缩意义不大。
#pragma once

#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace zip {

struct Entry {
    std::string name;        // UTF-8 文件名（可能含子目录）
    uint64_t size = 0;       // 未压缩大小
    uint64_t offset = 0;     // 数据在 zip 中的偏移
    uint32_t method = 0;     // 0 = store
    bool utf8 = false;
};

class Reader {
public:
    Reader(const uint8_t *data, size_t size) : data_(data), size_(size) {}

    bool parse() {
        if (size_ < 22) return false;
        // 从尾部找 EOCD（0x06054b50）
        size_t eocd = 0;
        bool found = false;
        size_t limit = size_ > 66000 ? size_ - 66000 : 0;
        for (size_t i = size_ - 22 + 1; i-- > limit;) {
            if (read32(i) == 0x06054b50u) {
                eocd = i;
                found = true;
                break;
            }
            if (i == 0) break;
        }
        if (!found) return false;

        uint16_t count = read16(eocd + 10);
        uint32_t cd_offset = read32(eocd + 16);
        if (cd_offset >= size_) return false;

        size_t p = cd_offset;
        for (uint16_t i = 0; i < count; ++i) {
            if (p + 46 > size_ || read32(p) != 0x02014b50u) break;
            uint16_t flags = read16(p + 8);
            uint32_t method = read16(p + 10);
            uint32_t csize = read32(p + 20);
            uint32_t usize = read32(p + 24);
            uint16_t nameLen = read16(p + 28);
            uint16_t extraLen = read16(p + 30);
            uint16_t commentLen = read16(p + 32);
            uint32_t localOffset = read32(p + 42);
            (void)csize;

            Entry e;
            e.name = std::string((const char *)data_ + p + 46, nameLen);
            e.size = usize;
            e.method = method;
            e.utf8 = (flags & 0x0800) != 0;

            // 本地头：30 + nameLen + extraLen 之后就是数据
            if (localOffset + 30 > size_ || read32(localOffset) != 0x04034b50u) break;
            uint16_t lNameLen = read16(localOffset + 26);
            uint16_t lExtraLen = read16(localOffset + 28);
            e.offset = (uint64_t)localOffset + 30 + lNameLen + lExtraLen;
            if (e.offset + e.size > size_) break;

            entries_.push_back(e);
            p += 46 + nameLen + extraLen + commentLen;
        }
        return !entries_.empty();
    }

    const std::vector<Entry> &entries() const { return entries_; }

    bool read(const Entry &e, std::vector<uint8_t> &out) const {
        if (e.offset + e.size > size_) return false;
        out.assign(data_ + e.offset, data_ + e.offset + e.size);
        return true;
    }

private:
    uint16_t read16(size_t p) const {
        return (uint16_t)(data_[p] | (data_[p + 1] << 8));
    }
    uint32_t read32(size_t p) const {
        return (uint32_t)data_[p] | ((uint32_t)data_[p + 1] << 8) |
               ((uint32_t)data_[p + 2] << 16) | ((uint32_t)data_[p + 3] << 24);
    }

    const uint8_t *data_;
    size_t size_;
    std::vector<Entry> entries_;
};

}  // namespace zip

"""打包并编译 AI Downloader 安装程序。

做三件事：
  1. 把程序文件收集进 payload.zip（**不压缩**，STORE —— 安装端不需要 inflate 实现）；
  2. 生成资源脚本 payload.rc（内嵌 zip + 版本信息），用 windres 编译成 .o；
  3. 用 g++ 编译 setup.cpp 并链接资源，产出单文件安装包 AIDownloaderSetup.exe。

用法：
    python build.py                # 打包并编译
    python build.py --no-build     # 只打包（生成 payload.zip）
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent                      # 项目根目录（AIDownloader）
OUT = HERE / "out"
GXX_CANDIDATES = [r"D:\mingw64\bin\g++.exe", "g++"]
WINDRES_CANDIDATES = [r"D:\mingw64\bin\windres.exe", "windres"]

VERSION = "1.0.0"
VERSION_TUPLE = (1, 0, 0, 0)
APP_NAME = "AI Downloader"

# 打进安装包的路径（相对项目根目录）
INCLUDE_FILES = ["AIDownloader.pyw", "README.md"]
INCLUDE_DIRS = ["app"]
# 可选：一并带上 support files 数据库工具
OPTIONAL = [
    (ROOT.parent / "OllamaModelDB" / "aidb.exe", "tools/aidb.exe"),
    (ROOT.parent / "OllamaModelDB" / "README.md", "tools/aidb-README.md"),
]
EXCLUDE_DIRS = {"__pycache__", ".git", "screenshots", "installer"}
EXCLUDE_SUFFIX = (".pyc", ".pyo")


def tool(cands):
    for c in cands:
        if os.path.sep in c or "/" in c:
            if Path(c).exists():
                return c
        else:
            found = shutil.which(c)
            if found:
                return found
    return None


def collect() -> list[tuple[Path, str]]:
    """返回 [(源文件, zip 内路径)]。"""
    files: list[tuple[Path, str]] = []
    for name in INCLUDE_FILES:
        p = ROOT / name
        if p.exists():
            files.append((p, name))
        else:
            print(f"  ! 缺少 {name}（跳过）")
    for d in INCLUDE_DIRS:
        base = ROOT / d
        if not base.exists():
            print(f"  ! 缺少目录 {d}（跳过）")
            continue
        for p in sorted(base.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(ROOT)
            if any(part in EXCLUDE_DIRS for part in rel.parts):
                continue
            if p.suffix in EXCLUDE_SUFFIX:
                continue
            files.append((p, str(rel).replace("\\", "/")))
    for src, dest in OPTIONAL:
        if src.exists():
            files.append((src, dest))
        else:
            print(f"  · 可选项不存在，跳过：{src}")
    return files


def make_payload(files) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    payload = OUT / "payload.zip"
    if payload.exists():
        payload.unlink()
    total = 0
    with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_STORED) as zf:
        for src, dest in files:
            zf.write(src, dest)
            total += src.stat().st_size
    print(f"  payload.zip：{len(files)} 个文件，{total/1024:.1f} KB "
          f"-> {payload.stat().st_size/1024:.1f} KB")
    return payload


def make_resource(payload: Path) -> Path:
    rc = OUT / "payload.rc"
    # 资源脚本用相对路径 + 正确的转义，交给 windres 处理
    zip_path = str(payload).replace("\\", "/")
    text = f'''#include <windows.h>

{101} RCDATA "{zip_path}"

VS_VERSION_INFO VERSIONINFO
FILEVERSION    {VERSION_TUPLE[0]},{VERSION_TUPLE[1]},{VERSION_TUPLE[2]},{VERSION_TUPLE[3]}
PRODUCTVERSION {VERSION_TUPLE[0]},{VERSION_TUPLE[1]},{VERSION_TUPLE[2]},{VERSION_TUPLE[3]}
FILEFLAGSMASK  VS_FFI_FILEFLAGSMASK
FILEFLAGS      0
FILEOS         VOS_NT_WINDOWS32
FILETYPE       VFT_APP
FILESUBTYPE    VFT2_UNKNOWN
BEGIN
    BLOCK "StringFileInfo"
    BEGIN
        BLOCK "080404b0"
        BEGIN
            VALUE "CompanyName",      "{APP_NAME}"
            VALUE "FileDescription",  "{APP_NAME} Setup"
            VALUE "FileVersion",      "{VERSION}"
            VALUE "InternalName",     "AIDownloaderSetup"
            VALUE "OriginalFilename", "AIDownloaderSetup.exe"
            VALUE "ProductName",      "{APP_NAME}"
            VALUE "ProductVersion",   "{VERSION}"
            VALUE "LegalCopyright",   "MIT License"
        END
    END
    BLOCK "VarFileInfo"
    BEGIN
        VALUE "Translation", 0x804, 1200
    END
END
'''
    rc.write_text(text, encoding="utf-8")
    print(f"  payload.rc 已生成（内嵌 {payload.name} + 版本信息）")
    return rc


def build(rc: Path) -> Path:
    gxx = tool(GXX_CANDIDATES)
    windres = tool(WINDRES_CANDIDATES)
    if not gxx or not windres:
        print("找不到 g++ 或 windres，请安装 MinGW-w64")
        sys.exit(1)
    res = OUT / "payload.o"
    subprocess.run([windres, str(rc), "-O", "coff", "-o", str(res)], check=True)
    exe = OUT / "AIDownloaderSetup.exe"
    cmd = [gxx, "-std=c++17", "-O2", "-mwindows", "-static", "-static-libgcc",
           "-static-libstdc++", "-o", str(exe), str(HERE / "setup.cpp"), str(res),
           "-lcomctl32", "-lshell32", "-ladvapi32", "-lole32", "-luuid", "-luser32",
           "-lgdi32"]
    print("  编译：", " ".join(cmd[:6]), "…")
    subprocess.run(cmd, check=True)
    print(f"  生成 {exe.name}（{exe.stat().st_size/1024:.1f} KB）")
    return exe


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-build", action="store_true", help="只打包，不编译")
    args = ap.parse_args()

    print(f"打包 {APP_NAME} {VERSION}")
    files = collect()
    payload = make_payload(files)
    rc = make_resource(payload)
    if args.no_build:
        return
    exe = build(rc)
    print(f"\n完成：{exe}")
    print("  图形界面：直接双击")
    print("  静默安装：AIDownloaderSetup.exe /S /D=D:\\Tools\\AIDownloader")
    print("  卸载    ：AIDownloaderSetup.exe /uninstall  （或安装目录里的 Uninstall.exe）")


if __name__ == "__main__":
    main()
